<?php
session_start();
// Připojení k databázi
include('db.php');

// Ověření, zda je formulář odeslán
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $username = trim($_POST['username']);
    $password = $_POST['password'];

    // Ověření, že uživatelské jméno a heslo nejsou prázdné
    if (empty($username) || empty($password)) {
        $error_message = "Uživatelské jméno a heslo jsou povinné!";
    } else {
        // Ochrana proti SQL injection
        $username_escaped = mysqli_real_escape_string($conn, $username);
        $password_hashed = md5($password);

        // Dotaz na uživatele
        $sql = "SELECT id, username, password FROM users WHERE username = '$username_escaped'";
        $result = mysqli_query($conn, $sql);

        if ($result && mysqli_num_rows($result) > 0) {
            $row = mysqli_fetch_assoc($result);
            // Ověření hesla
            if ($row['password'] === $password_hashed) {
                // Přihlášení úspěšné - nastavíme session a zobrazíme hlášku
                $_SESSION['user_id'] = $row['id'];
                $_SESSION['username'] = $row['username'];
                $success_message = "Přihlášení úspěšné (" . htmlspecialchars($row['username']) . ")";
                // Přesměrování po 2 sekundách
                echo "<meta http-equiv='refresh' content='2;url=index.php'>";
            } else {
                $error_message = "Nesprávné uživatelské jméno nebo heslo!";
            }
        } else {
            $error_message = "Uživatelské jméno neexistuje!";
        }
    }
}
?>

<!DOCTYPE html>
<html lang="cs">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Přihlášení</title>
    <link rel="stylesheet" href="css/style.css">
    <link rel="stylesheet" href="css/nav.css">
    <style>
        .nav-open-btn, .nav-close-btn {
            background: #229954;
            color: #fff;
            border: none;
            border-radius: 5px;
            font-size: 1.1em;
            padding: 8px 18px;
            margin: 8px 0;
            cursor: pointer;
            transition: background 0.2s;
            font-family: 'Segoe UI', 'Roboto', 'Arial', 'Helvetica Neue', sans-serif;
            letter-spacing: 2px;
        }
        .nav-open-btn:hover, .nav-close-btn:hover {
            background: #28b463;
        }
        .nav-close-btn {
            width: 100%;
            margin-top: 10px;
        }
    </style>
</head>
<body>
<?php include 'navbar.php'; ?>
<br><br>
<div class="register-wrapper" style="min-height:100vh;display:block;">
    <div class="login-container" style="margin:40px auto 0 auto;">
        <h2 class="register-heading">Přihlášení</h2>
        <?php
        if (isset($error_message)) {
            echo "<p class='error'>$error_message</p>";
        }
        if (isset($success_message)) {
            echo "<p class='success'>$success_message</p>";
        }
        ?>
        <form action="login.php" method="POST" class="login-form">
            <label for="username">Uživatelské jméno:</label>
            <input type="text" id="username" name="username" required><br><br>

            <label for="password">Heslo:</label>
            <input type="password" id="password" name="password" required><br><br>

            <input type="submit" value="Přihlásit se">
        </form>
        <p>Nemáte účet? <a href="register.php">Registrujte se zde</a></p>
    </div>
</div>
<script>
    const nav = document.getElementById('mainNav');
    const overlay = document.getElementById('navOverlay');
    const navOpenBtn = document.getElementById('navOpenBtn');
    const navCloseBtn = document.getElementById('navCloseBtn');
    function openNav() {
        nav.style.display = 'block';
        overlay.classList.add('active');
        navOpenBtn.style.display = 'none';
    }
    function closeNav() {
        nav.style.display = 'none';
        overlay.classList.remove('active');
        navOpenBtn.style.display = 'block';
    }
    navOpenBtn.addEventListener('click', openNav);
    navCloseBtn.addEventListener('click', closeNav);
    overlay.addEventListener('click', closeNav);
    function handleResize() {
        if (window.innerWidth <= 768) {
            closeNav();
        } else {
            nav.style.display = 'block';
            overlay.classList.remove('active');
            navOpenBtn.style.display = 'none';
        }
    }
    handleResize();
    window.addEventListener('resize', handleResize);
</script>
</body>
</html>
</html>
